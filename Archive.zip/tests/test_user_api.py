import pytest
from tests.base_test import BaseAPITest

class TestUserAPI(BaseAPITest):
    def test_get_user_info(self):
        """测试获取用户信息"""
        # 发送请求
        response = self.make_request('GET', '/api/users/1')
        
        # 保存响应
        self.save_response_json(response, 'responses/user_info_response.json')
        
        # 比较响应数据
        assert self.compare_response_data(response, 'expected/user_info.json')

    def test_create_user(self):
        """测试创建用户"""
        # 加载请求数据
        request_data = self.load_json_file('requests/create_user.json')
        
        # 发送请求
        response = self.make_request('POST', '/api/users', data=request_data)
        
        # 保存响应
        self.save_response_json(response, 'responses/create_user_response.json')
        
        # 比较响应数据
        assert self.compare_response_data(response, 'expected/create_user.json') 